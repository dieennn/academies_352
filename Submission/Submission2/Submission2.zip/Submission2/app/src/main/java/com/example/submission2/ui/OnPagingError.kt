package com.example.submission2.ui

interface OnPagingError {
    fun onError(message: String)
}