package com.example.submission2.ui.view.main

enum class Location(val isOn: Int) {
    LOCATION_ON(1),
    LOCATION_OFF(0)
}